#!/usr/bin/env python3
"""Serve the model over HTTP.  GET /health   GET /predict?text=server+is+down"""
import http.server, json, math, os, urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MODEL = json.loads((ROOT / "model" / "model.json").read_text())
CARD = json.loads((ROOT / "model" / "card.json").read_text())
PORT = int(os.environ.get("PORT", "8080"))

def score(text):
    z = MODEL["bias"] + sum(MODEL["weights"].get(t, 0.0) for t in set(text.lower().split()))
    return 1 / (1 + math.exp(-max(min(z, 30), -30)))

class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *a):
        print(f"{self.command} {self.path} -> {a[1] if len(a) > 1 else ''}", flush=True)
    def send(self, code, body):
        data = json.dumps(body).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        if u.path == "/health":
            return self.send(200, {"status": "ok", "model": CARD["model_sha256"], "commit": CARD["git_commit"]})
        if u.path == "/predict":
            text = urllib.parse.parse_qs(u.query).get("text", [""])[0]
            p = score(text)
            return self.send(200, {"text": text, "label": "urgent" if p >= 0.5 else "normal", "confidence": round(max(p, 1 - p), 3)})
        self.send(404, {"error": "try /health or /predict?text=..."})

if __name__ == "__main__":
    print(f"serving model {CARD['model_sha256']} (commit {CARD['git_commit']}) on port {PORT}", flush=True)
    http.server.HTTPServer(("0.0.0.0", PORT), H).serve_forever()
