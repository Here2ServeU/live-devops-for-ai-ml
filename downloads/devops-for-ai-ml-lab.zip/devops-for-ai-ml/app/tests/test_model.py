import json, subprocess, sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

class TestData(unittest.TestCase):
    def test_csv_has_header_and_rows(self):
        lines = (ROOT / "data" / "tickets.csv").read_text().splitlines()
        self.assertEqual(lines[0], "id,text,label")
        self.assertGreater(len(lines), 100)

    def test_labels_are_known(self):
        import csv
        with open(ROOT / "data" / "tickets.csv") as f:
            labels = {r["label"] for r in csv.DictReader(f)}
        self.assertEqual(labels, {"urgent", "normal"})

class TestParams(unittest.TestCase):
    def test_seed_is_pinned(self):
        params = json.loads((ROOT / "params.json").read_text())
        self.assertIsNotNone(params["seed"], "pin the seed in params.json so training is reproducible")

if __name__ == "__main__":
    unittest.main()
