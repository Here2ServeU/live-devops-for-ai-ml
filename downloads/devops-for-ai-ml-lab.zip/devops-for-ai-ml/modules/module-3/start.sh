#!/usr/bin/env bash
# Module 3: put ~/ticket-triage in the end-of-Module-2 state.
set -e
bash "$(dirname "$0")/../module-2/start.sh" "${1:-}" >/dev/null
cd "${LAB_DIR:-$HOME/ticket-triage}"
cp Dockerfile.fixed Dockerfile && cp .dockerignore.fixed .dockerignore
git add -A && git commit -q -m "safe Dockerfile and .dockerignore" || true
echo "Ready: ~/ticket-triage  (seed pinned, safe Dockerfile)"
echo "Next:  cd ~/ticket-triage && bash pipeline.sh"
