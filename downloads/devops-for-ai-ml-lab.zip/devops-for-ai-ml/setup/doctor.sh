#!/usr/bin/env bash
# DevOps for AI-ML Systems - environment check.  Run: bash setup/doctor.sh
ok()   { printf "  [ OK ]  %s\n" "$1"; }
warn() { printf "  [WARN]  %s\n" "$1"; }
echo "DevOps for AI-ML Systems - doctor"
echo "---------------------------------"
[ "$(uname -s)" = "Linux" ] && ok "Linux $(uname -r)" || warn "Not Linux. Use Codespaces, WSL or Multipass."
command -v git >/dev/null && ok "$(git --version)" || warn "git missing: sudo apt install -y git"
command -v python3 >/dev/null && ok "$(python3 --version)" || warn "python3 missing: sudo apt install -y python3"
if command -v docker >/dev/null && docker info >/dev/null 2>&1; then ok "Docker $(docker version --format '{{.Server.Version}}' 2>/dev/null)"
elif command -v docker >/dev/null; then warn "Docker installed but not usable. Try: sudo usermod -aG docker \$USER, then log out and in."
else warn "Docker missing (needed from Module 2): sudo apt install -y docker.io"; fi
git config user.name >/dev/null && ok "git user: $(git config user.name)" || warn "Set your git name: git config --global user.name \"Your Name\""
echo "---------------------------------"
echo "Module 1 needs git + python3. Modules 2-3 also need Docker."
