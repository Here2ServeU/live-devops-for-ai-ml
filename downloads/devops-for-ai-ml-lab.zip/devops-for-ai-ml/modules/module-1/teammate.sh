#!/usr/bin/env bash
# Module 1: pretend a teammate quietly edited the training data.
set -e
cd "${LAB_DIR:-$HOME/ticket-triage}"
python3 - <<'P'
import csv, random
rows = list(csv.reader(open("data/tickets.csv")))
rng = random.Random(1)
for r in rows[1:]:
    if rng.random() < 0.08:
        r[2] = "normal" if r[2] == "urgent" else "urgent"   # relabel a few tickets
csv.writer(open("data/tickets.csv", "w", newline="")).writerows(rows)
P
echo "A teammate changed something. Your model's accuracy may move. Find out what changed."
