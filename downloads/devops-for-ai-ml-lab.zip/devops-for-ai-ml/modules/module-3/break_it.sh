#!/usr/bin/env bash
# Module 3: pretend someone pushed a 'harmless' tuning change.
set -e
cd "${LAB_DIR:-$HOME/ticket-triage}"
python3 - <<'P'
import json; p=json.load(open("params.json")); p["epochs"]=1; p["learning_rate"]=0.001
json.dump(p, open("params.json","w"), indent=2); open("params.json","a").write("\n")
P
git commit -qam "tune: faster training (1 epoch)"
echo "A teammate just committed: 'tune: faster training (1 epoch)'. Run the pipeline."
