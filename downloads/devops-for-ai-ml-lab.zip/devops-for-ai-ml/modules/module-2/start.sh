#!/usr/bin/env bash
# Module 2: put ~/ticket-triage in the end-of-Module-1 state, add a secret, train a model.
set -e
source "$(dirname "$0")/../common.sh"
if [ ! -d "$LAB/.git" ] || [ "${1:-}" = "--reset" ]; then
  fresh_copy
  git add -A && git commit -q -m "baseline: ticket-triage model, data and code"
fi
cd "$LAB"
python3 - <<'P'
import json; p=json.load(open("params.json")); p["seed"]=p["seed"] or 42; json.dump(p, open("params.json","w"), indent=2); open("params.json","a").write("\n")
P
git add params.json && git commit -q -m "pin seed for reproducible training" || true
printf 'export HF_TOKEN=hf_lab_example_not_a_real_token\n' > .env && chmod 600 .env
python3 src/train.py >/dev/null
echo "Ready: $LAB  (seed pinned, model trained, a .env secret present)"
echo "Next:  cd ~/ticket-triage && cat Dockerfile"
