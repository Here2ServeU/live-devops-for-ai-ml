#!/usr/bin/env python3
"""Generate the support-ticket dataset (deterministic). Run: python3 src/make_data.py"""
import csv, random
from pathlib import Path

URGENT = ["down", "outage", "crash", "cannot", "login", "failed", "error", "urgent", "broken", "data", "loss", "payment", "security", "breach", "timeout"]
NORMAL = ["question", "how", "feature", "request", "docs", "thanks", "update", "invoice", "change", "name", "color", "export", "report", "idea", "tutorial"]
COMMON = ["the", "my", "a", "please", "help", "with", "our", "team", "app", "account", "today", "is"]

def main(n=1200, seed=7):
    rng = random.Random(seed)
    out = Path(__file__).resolve().parent.parent / "data" / "tickets.csv"
    out.parent.mkdir(exist_ok=True)
    with open(out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["id", "text", "label"])
        for i in range(1, n + 1):
            label = "urgent" if rng.random() < 0.4 else "normal"
            own, other = (URGENT, NORMAL) if label == "urgent" else (NORMAL, URGENT)
            words = rng.sample(COMMON, 3) + rng.sample(own, 2)
            if rng.random() < 0.25:
                words.append(rng.choice(other))   # noise: real tickets are messy
            rng.shuffle(words)
            if rng.random() < 0.06:
                label = "normal" if label == "urgent" else "urgent"   # noise: some tickets are mislabelled
            w.writerow([i, " ".join(words), label])
    print(f"wrote {n} tickets to data/tickets.csv")

if __name__ == "__main__":
    main()
