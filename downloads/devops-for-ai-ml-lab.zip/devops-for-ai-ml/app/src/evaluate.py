#!/usr/bin/env python3
"""Quality gate: exit 0 if the model beats min_accuracy, exit 1 if not."""
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
bar = json.loads((ROOT / "params.json").read_text())["min_accuracy"]
acc = json.loads((ROOT / "model" / "metrics.json").read_text())["accuracy"]
if acc >= bar:
    print(f"GATE PASS  accuracy {acc:.1%} >= bar {bar:.0%}")
    sys.exit(0)
print(f"GATE FAIL  accuracy {acc:.1%} <  bar {bar:.0%}  - this model does not ship")
sys.exit(1)
