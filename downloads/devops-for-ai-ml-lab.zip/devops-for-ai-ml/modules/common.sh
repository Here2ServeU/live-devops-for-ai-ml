# shared helpers for the module start scripts
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LAB="${LAB_DIR:-$HOME/ticket-triage}"
fresh_copy() {
  rm -rf "$LAB"
  cp -r "$REPO_ROOT/app" "$LAB"
  cd "$LAB"
  python3 src/make_data.py >/dev/null
  mkdir -p .lab && cp "$REPO_ROOT/modules/module-1/teammate.sh" "$REPO_ROOT/modules/module-3/break_it.sh" .lab/
  git init -q -b main
  git config user.name  >/dev/null || git config user.name  "T2S Learner"
  git config user.email >/dev/null || git config user.email "learner@example.com"
}
