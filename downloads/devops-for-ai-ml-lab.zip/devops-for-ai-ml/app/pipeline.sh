#!/usr/bin/env bash
# The same pipeline GitHub Actions runs, on your machine.  Run: bash pipeline.sh
set -euo pipefail
cd "$(dirname "$0")"
step() { printf "\n==> %s\n" "$1"; }

step "1/4 TEST   unit tests on data and params"
python3 -m unittest discover -s tests -q

step "2/4 TRAIN  build the model"
python3 src/train.py

step "3/4 GATE   is it good enough to ship?"
python3 src/evaluate.py

step "4/4 BUILD  package it"
if command -v docker >/dev/null && docker info >/dev/null 2>&1; then
  TAG=$(git rev-parse --short HEAD 2>/dev/null || echo dev)
  docker build -q -t ticket-triage:"$TAG" . >/dev/null
  echo "built image ticket-triage:$TAG"
else
  echo "docker not available here - skipping build (CI will build it)"
fi
printf "\nPIPELINE GREEN - this model can ship.\n"
