#!/usr/bin/env python3
"""Train a tiny ticket-triage model (urgent vs normal). Standard library only.

Inputs : data/tickets.csv, params.json, this code, your Python version
Outputs: model/model.json, model/metrics.json, model/card.json
"""
import csv, hashlib, json, math, platform, random, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "tickets.csv"
OUT = ROOT / "model"

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git_commit():
    try:
        sha = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT, capture_output=True, text=True).stdout.strip()
        dirty = subprocess.run(["git", "status", "--porcelain", "--", "src", "data", "params.json"], cwd=ROOT, capture_output=True, text=True).stdout.strip()
        return (sha or "no-git") + ("-dirty" if dirty else "")
    except FileNotFoundError:
        return "no-git"

def load():
    with open(DATA) as f:
        rows = list(csv.DictReader(f))
    train = [r for r in rows if int(r["id"]) % 5 != 0]
    test = [r for r in rows if int(r["id"]) % 5 == 0]
    return train, test

def features(text):
    return set(text.lower().split())

def predict_proba(w, b, text):
    z = b + sum(w.get(t, 0.0) for t in features(text))
    return 1 / (1 + math.exp(-max(min(z, 30), -30)))

def main():
    params = json.loads((ROOT / "params.json").read_text())
    seed = params.get("seed")
    if seed is None:
        seed = time.time_ns() % 1_000_000          # unpinned: a new random seed every run
        print(f"WARNING seed is not pinned - using random seed {seed}")
    rng = random.Random(seed)
    train, test = load()
    vocab = sorted({t for r in train for t in features(r["text"])})
    w = {t: rng.uniform(-0.5, 0.5) for t in vocab}
    b = 0.0
    lr = params["learning_rate"]
    for epoch in range(params["epochs"]):
        rng.shuffle(train)
        for r in train:
            y = 1.0 if r["label"] == "urgent" else 0.0
            g = predict_proba(w, b, r["text"]) - y
            for t in features(r["text"]):
                w[t] -= lr * g
            b -= lr * g
    correct = sum((predict_proba(w, b, r["text"]) >= 0.5) == (r["label"] == "urgent") for r in test)
    acc = round(correct / len(test), 4)
    OUT.mkdir(exist_ok=True)
    (OUT / "model.json").write_text(json.dumps({"weights": {k: round(v, 6) for k, v in w.items()}, "bias": round(b, 6)}, sort_keys=True))
    (OUT / "metrics.json").write_text(json.dumps({"accuracy": acc, "test_rows": len(test)}, indent=2) + "\n")
    card = {"git_commit": git_commit(), "data_sha256": sha256(DATA)[:16], "params": params, "seed_used": seed,
            "python": platform.python_version(), "accuracy": acc, "model_sha256": sha256(OUT / "model.json")[:16]}
    (OUT / "card.json").write_text(json.dumps(card, indent=2) + "\n")
    print(f"trained on {len(train)} tickets · accuracy {acc:.1%} on {len(test)} held-out tickets")
    print(f"model sha256 {card['model_sha256']}  (model/card.json has the full receipt)")

if __name__ == "__main__":
    main()
