# ticket-triage

A tiny model that labels support tickets as urgent or normal.
Used in DevOps for AI-ML Systems (T2S).

    python3 src/train.py      # train
    python3 src/evaluate.py   # quality gate
    python3 src/serve.py      # serve on :8080
    bash pipeline.sh          # test -> train -> gate -> build
