# DevOps for AI-ML Systems

Transformed 2 Succeed (T2S) · Emmanuel Naweji

Ship models the way good teams ship code: reproducible, packaged, and gated.

| Module | Sticky idea | Lab |
|---|---|---|
| 1 · Ship the Model Like Code | **Same inputs, same model.** | Make training reproducible, catch a teammate's silent data change |
| 2 · Pack It Once | **Pack it once. Run it anywhere.** | Containerize the model; find the secret baked into the image |
| 3 · No Green, No Ship | **No green, no ship.** | A pipeline whose quality gate blocks a bad model |

## Setup (one time)

- **Any computer:** GitHub Codespaces (this repo includes a devcontainer with Python 3.12 + Docker)
- **Windows:** WSL Ubuntu, then `sudo apt install -y docker.io git python3` and `sudo usermod -aG docker $USER`
- **Mac:** Multipass Ubuntu VM, then the same apt command

```bash
git clone https://github.com/Here2ServeU/devops-for-ai-ml
cd devops-for-ai-ml && bash setup/doctor.sh
```

## Labs

```bash
bash modules/module-1/start.sh   # creates ~/ticket-triage as a fresh git project
bash modules/module-2/start.sh   # end-of-Module-1 state + a .env secret
bash modules/module-3/start.sh   # end-of-Module-2 state, safe Dockerfile
```

`app/` is the ticket-triage project (standard-library Python only). `app/.github/workflows/ml-pipeline.yml`
is the GitHub Actions pipeline you push in Module 3.
