#!/usr/bin/env bash
# Module 1: create ~/ticket-triage as a brand-new git project.
set -e
source "$(dirname "$0")/../common.sh"
fresh_copy
git add -A && git commit -q -m "baseline: ticket-triage model, data and code"
echo "Ready: $LAB  (one commit, seed NOT pinned yet)"
echo "Next:  cd ~/ticket-triage && git log --oneline"
